# alexa-firebase
Simple alexa skill that retrieves from a firebase database.
